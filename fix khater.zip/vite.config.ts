import { defineConfig } from 'vite';
import { resolve } from 'path';

export default defineConfig({
  root: '.',
  publicDir: 'public',
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    rollupOptions: {
      input: {
        main: resolve(__dirname, 'index.html'),
        about: resolve(__dirname, 'مركز/about.html'),
        contact: resolve(__dirname, 'مركز/contact.html'),
        refrigerator: resolve(__dirname, 'مركز/refrigerator.html'),
        freezer: resolve(__dirname, 'مركز/freezer.html'),
        washer: resolve(__dirname, 'مركز/washer.html'),
        dishwasher: resolve(__dirname, 'مركز/dishwasher.html'),
        privacy: resolve(__dirname, 'مركز/privacy.html'),
        terms: resolve(__dirname, 'مركز/terms.html'),
        toshiba: resolve(__dirname, 'مركز/toshiba.html'),
        lg: resolve(__dirname, 'مركز/lg.html'),
        kiriazi: resolve(__dirname, 'مركز/kiriazi.html'),
        beko: resolve(__dirname, 'مركز/beko.html'),
        bosch: resolve(__dirname, 'مركز/bosch.html'),
        whitewhale: resolve(__dirname, 'مركز/whitewhale.html'),
        whitepoint: resolve(__dirname, 'مركز/whitepoint.html'),
        daewoo: resolve(__dirname, 'مركز/daewoo.html'),
        westinghouse: resolve(__dirname, 'مركز/westinghouse.html'),
        frigidaire: resolve(__dirname, 'مركز/frigidaire.html'),
        whirlpool: resolve(__dirname, 'مركز/whirlpool.html'),
        samsung: resolve(__dirname, 'مركز/samsung.html'),
        hitachi: resolve(__dirname, 'مركز/hitachi.html'),
        universal: resolve(__dirname, 'مركز/universal.html'),
        ariston: resolve(__dirname, 'مركز/ariston.html'),
      },
    },
  },
  server: {
    port: 3000,
    open: true,
  },
});
